# Valhalla Helm Chart

This chart deploys Valhalla on GKE with routing data distributed through a Google Cloud Storage bucket and a scheduled safe refresh job.

## Design

- Valhalla pods use an init container to read `gs://<bucket>/<prefix>/current.txt` and download that release into a local `emptyDir` mounted at `/data`.
- The serving command reads `/data/current/valhalla.json`.
- A CronJob builds fresh data into an `emptyDir`, uploads the completed build to `gs://<bucket>/<prefix>/releases/<timestamp>`, then updates `current.txt`.
- After publishing, you can restart the Deployment manually during a controlled rollout, or explicitly allow the CronJob to do it automatically.
- No Filestore or `ReadWriteMany` volume is required. Each pod keeps a local copy of the selected release.

## GKE Permissions

The preferred GKE production setup is Workload Identity for the Kubernetes service accounts:

- the Valhalla serving service account needs read access to the bucket, for example `roles/storage.objectViewer`
- the refresh service account needs write access, for example `roles/storage.objectAdmin`

Annotate the Kubernetes service accounts through values:

```yaml
serviceAccount:
  annotations:
    iam.gke.io/gcp-service-account: valhalla-reader@PROJECT_ID.iam.gserviceaccount.com

refresh:
  serviceAccount:
    annotations:
      iam.gke.io/gcp-service-account: valhalla-writer@PROJECT_ID.iam.gserviceaccount.com
```

If you need to use a JSON key instead, create a Kubernetes secret and enable `GOOGLE_APPLICATION_CREDENTIALS` mounting:

```sh
kubectl create secret generic valhalla-gcs-credentials \
  --namespace valhalla \
  --from-file=credentials.json=/path/to/service-account.json
```

```yaml
gcs:
  credentials:
    enabled: true
    existingSecret: valhalla-gcs-credentials
    key: credentials.json
```

The chart mounts that secret at `/var/secrets/google` and sets `GOOGLE_APPLICATION_CREDENTIALS=/var/secrets/google/credentials.json` in the GCS fetch and publish containers.

Alternatively, Helm can create that Kubernetes Secret from an encrypted SOPS `secrets.yaml` file. Enable secret creation in normal values:

```yaml
gcs:
  credentials:
    enabled: true
    createSecret: true
    existingSecret: valhalla-gcs-credentials
    key: credentials.json
```

Then put the JSON key in the encrypted secrets file:

```yaml
gcs:
  credentials:
    json: |-
      { ... service account JSON ... }
```

Do not commit the plaintext file; encrypt it with SOPS and include it via Helmfile `secrets:`.

## Production Rollouts

By default, the refresh CronJob only publishes a new GCS release and updates `current.txt`; it does not restart serving pods. That is safer for production because a data refresh cannot unexpectedly roll every Valhalla pod during peak traffic.

To move serving pods to the new dataset, run a controlled rollout during your maintenance window:

```sh
kubectl rollout restart deployment/valhalla -n valhalla
kubectl rollout status deployment/valhalla -n valhalla --timeout=10m
```

The chart uses `maxUnavailable: 0` and `maxSurge: 1` by default, so Kubernetes starts a replacement pod, waits for it to become ready, then terminates an old pod.

If you intentionally want the refresh job to restart Valhalla automatically after publishing new data, enable it explicitly:

```yaml
refresh:
  rolloutRestart:
    enabled: true
    timeout: 10m
```

## Install

```sh
helm upgrade --install valhalla ./helm/valhalla \
  --namespace valhalla \
  --create-namespace \
  --set gcs.bucket=YOUR_BUCKET_NAME
```

## Useful Overrides

```sh
helm upgrade --install valhalla ./helm/valhalla \
  --namespace valhalla \
  --create-namespace \
  --set gcs.bucket=YOUR_BUCKET_NAME \
  --set refresh.osmPbfUrl=https://download.geofabrik.de/europe/romania-latest.osm.pbf \
  --set replicaCount=2
```

Build and publish the first routing data release manually after installing:

```sh
kubectl create job --from=cronjob/valhalla-refresh valhalla-refresh-now -n valhalla
```

Before the first refresh job completes, serving pods will stay unready because `current.txt` does not exist yet.

## Bucket Layout

```text
gs://YOUR_BUCKET_NAME/valhalla/current.txt
gs://YOUR_BUCKET_NAME/valhalla/releases/20260909030000/valhalla.json
gs://YOUR_BUCKET_NAME/valhalla/releases/20260909030000/valhalla_tiles.tar
gs://YOUR_BUCKET_NAME/valhalla/releases/20260909030000/valhalla_tiles/...
```

Use a GCS lifecycle rule to expire old `valhalla/releases/*` prefixes after the retention period you want.
