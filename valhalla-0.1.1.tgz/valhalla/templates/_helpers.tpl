{{- define "valhalla.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "valhalla.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "valhalla.labels" -}}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version | replace "+" "_" }}
app.kubernetes.io/name: {{ include "valhalla.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{- define "valhalla.selectorLabels" -}}
app.kubernetes.io/name: {{ include "valhalla.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{- define "valhalla.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{- default (include "valhalla.fullname" .) .Values.serviceAccount.name -}}
{{- else -}}
{{- default "default" .Values.serviceAccount.name -}}
{{- end -}}
{{- end -}}

{{- define "valhalla.refreshServiceAccountName" -}}
{{- include "valhalla.fullname" . -}}-refresh
{{- end -}}

{{- define "valhalla.gcsCredentialsSecretName" -}}
{{- if .Values.gcs.credentials.existingSecret -}}
{{- .Values.gcs.credentials.existingSecret -}}
{{- else -}}
{{- include "valhalla.fullname" . -}}-gcs-credentials
{{- end -}}
{{- end -}}
